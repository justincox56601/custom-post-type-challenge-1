<?php
/*
    This is the custom resources post template

    
*/

get_template_part('resources/resources', 'header'); //use the header I created for this instead of theme header

get_template_part('resources/resources', 'details-single');

get_footer();
?>

